﻿namespace CarAPI.Payment
{
    public interface ICashService
    {
        string Pay(double amount);
    }
}